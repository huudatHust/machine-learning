package com.relax.stress.jedyteam.pixelthought;

public class Star {
    private int dx;
    private int dy;
    private int size;
    private int speed;

    public Star(int dx, int dy, int size, int speed) {
        this.dx = dx;
        this.dy = dy;
        this.size = size;
        this.speed = speed;
    }

    public void setDx(int dx) {
        this.dx = dx;
    }

    public void setDy(int dy) {
        this.dy = dy;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public int getDx() {
        return dx;
    }

    public int getDy() {
        return dy;
    }

    public int getSize() {
        return size;
    }

    public int getSpeed() {
        return speed;
    }
}
