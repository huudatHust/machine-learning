package com.relax.stress.jedyteam.pixelthought;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;


public class MainStarView extends View {

    private Paint paintMainStar = new Paint();
    private Path pathMainStar = new Path();

    public MainStarView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        paintMainStar.setAntiAlias(true);
        paintMainStar.setColor(Color.WHITE);
        paintMainStar.setShadowLayer(30, 0, 0, Color.YELLOW);

        setLayerType(LAYER_TYPE_SOFTWARE, paintMainStar);
        paintMainStar.setStyle(Paint.Style.FILL);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawPath(pathMainStar, paintMainStar);
    }

    public void drawMainStar(int size) {
        pathMainStar.reset();
        pathMainStar.addCircle(size, size, size - 30, Path.Direction.CW);
        postInvalidate();
    }

}
