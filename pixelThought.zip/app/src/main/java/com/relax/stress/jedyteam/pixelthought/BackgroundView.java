package com.relax.stress.jedyteam.pixelthought;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;


public class BackgroundView extends View {
    private boolean isUpdateView = true;
    private Paint paintStar = new Paint();
    private Path pathStar = new Path();
    private Paint paintMainStar = new Paint();
    private int MAX_QUEUE_SIZE;

    String text;
    private int mWidth;
    private int mHeight;

    public ArrayList<Star> listStar = null;
    public Queue<Star> qe = null;


    public BackgroundView(Context context) {
        super(context);


    }

    public BackgroundView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        listStar = new ArrayList<>();
        qe = new LinkedList<Star>();

        paintStar.setAntiAlias(true);
        paintStar.setColor(Color.WHITE);
        paintStar.setStyle(Paint.Style.FILL);

        paintMainStar.setAntiAlias(true);
        paintMainStar.setColor(Color.WHITE);
        paintMainStar.setShadowLayer(20, 0, 0, Color.YELLOW);
        setLayerType(LAYER_TYPE_SOFTWARE, paintMainStar);
        paintMainStar.setStyle(Paint.Style.FILL);

        DisplayMetrics displayMetrics = getContext().getResources().getDisplayMetrics();
        mWidth = displayMetrics.widthPixels;
        mHeight = displayMetrics.heightPixels;
        MAX_QUEUE_SIZE = (int)(mHeight/1920.0 * 60);

        Random r = new Random();
        for (int i = 0; i < 20; i++) {
            int dy = r.nextInt(mHeight - 0) + 0;
            int dx = r.nextInt(mWidth - 0) + 0;
            int speed = r.nextInt(5 - 1) + 1;
            int size = speed;
            qe.offer(new Star(dx, dy, size, speed + 5));
        }
        AddStar addStarThread = new AddStar();
        addStarThread.setDaemon(true);
        addStarThread.start();
        DrawStar drawStarThread = new DrawStar();
        drawStarThread.setDaemon(true);
        drawStarThread.start();
    }

    public BackgroundView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawPath(pathStar, paintStar);
    }


    class DrawStar extends Thread {
        @Override
        public void run() {
            try {
                while (true) {
                    try {
                        Iterator<Star> iter = qe.iterator();
                        while (iter.hasNext()) {
                            Star star = iter.next();
                            int dx = star.getDx();
                            int dy = star.getDy();
                            int size = star.getSize();
                            int speed = star.getSpeed();
                            pathStar.addRect(dx, dy, dx + size * 2, dy + size * 2, Path.Direction.CW);
                            star.setDy(dy - (speed));

                            if (star.getDy() < 0)
                                qe.remove(star);
                            postInvalidate();
                        }
                        sleep(80);
                        pathStar.reset();
                        postInvalidate();
                        if(!isUpdateView){
                            break;
                        }
                    } catch (ConcurrentModificationException e) {
                        e.printStackTrace();
                    }
                }
            } catch (InterruptedException e) {
            }
        }
    };

    class AddStar extends Thread {
        @Override
        public void run() {
            try {
                Random r = new Random();
                while (true) {
                    int dx = r.nextInt(mWidth - 0) + 0;
                    int size = r.nextInt(5 - 1) + 1;
                    int speed = size * 3;
                    if(qe.size() <= MAX_QUEUE_SIZE)
                        qe.offer(new Star(dx, mHeight + 3, size, speed));
                    sleep(480);
                    if(!isUpdateView){
                        break;
                    }
                }
            } catch (InterruptedException e) {
            }
        }
    };

    public void updateView(boolean b) {
        isUpdateView = b;
        if(isUpdateView) {
           // addStarThread.setDaemon(true);
            DrawStar drawStarThread = new DrawStar();
            drawStarThread.setDaemon(true);
            AddStar addStarThread = new AddStar();
            addStarThread.setDaemon(true);
            addStarThread.start();
            drawStarThread.start();
        }

    }

    public boolean getIsAlive(){
        return isUpdateView;
    }
}
