package com.relax.stress.jedyteam.pixelthought;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class Utils {
    public static final String STOP_MUSIC_ACTION =  "com.relax.stress.jedyteam.stopmusic";
    public static final String START_MUSIC_ACTION =  "com.relax.stress.jedyteam.startmusic";
    public static final String PAUSE_MUSIC_ACTION =  "com.relax.stress.jedyteam.pausemusic";
    public static boolean isNetworkAvailable(Context context) {
        ConnectivityManager connectivityMgr = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityMgr.getActiveNetworkInfo();
        /// if no network is available networkInfo will be null
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }
}
