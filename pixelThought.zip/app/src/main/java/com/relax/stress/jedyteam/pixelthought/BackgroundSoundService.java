package com.relax.stress.jedyteam.pixelthought;

import android.app.Notification;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
public class BackgroundSoundService extends Service {
    private static final String TAG = null;
    MediaPlayer player;
    private String ANDROID_CHANNEL_ID = "Pixel Thoughts";

    public IBinder onBind(Intent arg0) {
        return null;
    }
    @Override
    public void onCreate() {
        super.onCreate();
        player = MediaPlayer.create(this, R.raw.background);
        player.setLooping(true); // Set looping
        IntentFilter filter = new IntentFilter(Utils.START_MUSIC_ACTION);
        filter.addAction(Utils.STOP_MUSIC_ACTION);
        filter.addAction(Utils.PAUSE_MUSIC_ACTION);
        LocalBroadcastManager.getInstance(this).registerReceiver(receiver, filter);

    }
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {

            Notification.Builder builder = new Notification.Builder(this, ANDROID_CHANNEL_ID)
                    .setContentTitle(getString(R.string.app_name))
                    .setContentText("Run music background")
                    .setAutoCancel(true);

            Notification notification = builder.build();
            startForeground(1, notification);
        }
        if(!player.isPlaying())
            player.start();
        return START_NOT_STICKY;
    }

    public IBinder onUnBind(Intent arg0) {
        return null;
    }
    @Override
    public void onDestroy() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(receiver);
        player.stop();
        player.release();
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if(Utils.PAUSE_MUSIC_ACTION.equals(intent.getAction())){
                if(player.isPlaying())
                    player.pause();
            }
            if(Utils.START_MUSIC_ACTION.equals(intent.getAction())){
                if(!player.isPlaying())
                    player.start();
            }

            if(Utils.STOP_MUSIC_ACTION.equals(intent.getAction())){
                if(player.isPlaying())
                    player.stop();
                stopSelf();
            }
        }
    };
}
