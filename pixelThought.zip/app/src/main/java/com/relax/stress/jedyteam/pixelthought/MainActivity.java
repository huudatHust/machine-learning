package com.relax.stress.jedyteam.pixelthought;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AlertDialog;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    private EditText text;
    private Button button;
    private Button btnRunAgain;
    private Button btnExit;
    private LinearLayout gRunAgain;
    private LinearLayout gMore;
    private RelativeLayout layoutMainStar;
    private TextView txtThought;
    private TextView txtHeader;
    private TextView txtShowText;
    private MainStarView mainStarView;
    private BackgroundView backgroundView;
    private ImageView musicControl, imgRate, imgShare, imgFeedback;

    private int mWidth, mHeight, dx, dy;
    private String[] mainHeader;
    private Intent svc = null;
    //need save instance
    private boolean isBoring =false, isAppStarted = false;
    private STATUS status = STATUS.NONE;
    private int mSize = -1;
    private int headerTextIndex = -1;
    private boolean musicOn = true;
    private Handler handler ;
    private DrawMainStarThread drawMainStarThread = null;
    private PlayMainHeader playMainHeader = null;
    private RelativeLayout.LayoutParams paramsMainStar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
        RelativeLayout.LayoutParams paramsButton = ((RelativeLayout.LayoutParams) button.getLayoutParams());
        paramsButton.bottomMargin = mHeight / 10;
        button.setLayoutParams(paramsButton);
        initMainStar();
        handler = new Handler();
        startApp();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        status = STATUS.RESUME;
    }

    private void startApp(){
        if(isAppStarted)
            return;
        isAppStarted = true;
        showSlow(musicControl, 2000);
        showSlow(txtHeader, 2000);
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        showSlow(text, 3000);
                        showSlow(button, 3000);
                        showSlow(layoutMainStar, 3000);
                        showSlow(gMore, 3000);
                        showSlow(txtThought, 3000);
                        showSlow(txtShowText, 3000);
                    }
                }, 3000);
                hideSlow(txtHeader, 3000);
            }
        }, 5000);

        svc=new Intent(this, BackgroundSoundService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
    }
    private void initMainStar(){
        text.setWidth(mWidth / 2 + 100);

        dx = mWidth / 2;
        dy = mHeight / 2;

        paramsMainStar = ((RelativeLayout.LayoutParams) layoutMainStar.getLayoutParams());
        paramsMainStar.alignWithParent = true;
        paramsMainStar.width = dx;
        paramsMainStar.height = dx;
        layoutMainStar.setLayoutParams(paramsMainStar);
        mainStarView.drawMainStar(mWidth / 4);
    }
    private void init() {
        text = (EditText) findViewById(R.id.edit_text);
        button = (Button) findViewById(R.id.button);
        layoutMainStar = (RelativeLayout) findViewById(R.id.layout_main_star);
        txtThought = (TextView) findViewById(R.id.text_thought);
        txtHeader = (TextView) findViewById(R.id.txt_header);
        txtShowText = (TextView) findViewById(R.id.show_text);
        mainStarView = (MainStarView) findViewById(R.id.main_star);
        backgroundView = (BackgroundView) findViewById(R.id.background_view);
        musicControl = (ImageView) findViewById(R.id.img_music_volume);
        imgRate = (ImageView) findViewById(R.id.img_rate);
        imgShare = (ImageView) findViewById(R.id.img_share);
        imgFeedback = (ImageView) findViewById(R.id.img_feedback);

        mainHeader = getResources().getStringArray(R.array.main_header);
        gRunAgain = (LinearLayout) findViewById(R.id.g_runagain);
        btnRunAgain = (Button) findViewById(R.id.btn_run_again);
        btnExit = (Button) findViewById(R.id.btn_exit);
        gMore = (LinearLayout) findViewById(R.id.ll_more);

        DisplayMetrics displayMetrics = this.getResources().getDisplayMetrics();
        mWidth = displayMetrics.widthPixels;
        mHeight = displayMetrics.heightPixels;
        setupUI(findViewById(R.id.gLayout));
        musicControl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                musicOn = !musicOn;
                if(musicOn){
                    musicControl.setImageDrawable(getDrawable(R.drawable.ic_volume_up_white_36));
                    sendBackgroundAction(ACTION.START);
                }else{
                    musicControl.setImageDrawable(getDrawable(R.drawable.ic_volume_off_white_36));
                    sendBackgroundAction(ACTION.PAUSE);
                }
            }
        });
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendBackgroundAction(ACTION.STOP);
                finish();
                moveTaskToBack(true);
            }
        });
        btnRunAgain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resetActivity();

            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(text.getText().toString().trim().length() == 0) {
                    txtThought.setText("");
                    return;
                }
                isBoring = true;
                txtThought.setText(text.getText());
                drawMainStarThread = new DrawMainStarThread();
                drawMainStarThread.start();
                text.setVisibility(View.GONE);
                button.setVisibility(View.GONE);
                gMore.setVisibility(View.GONE);
                playMainHeader = new PlayMainHeader();
                playMainHeader.start();

            }
        });

        imgRate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + getPackageName())));
            }
        });
        imgShare.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, "Share to....");
                i.putExtra(Intent.EXTRA_TEXT, "https://play.google.com/store/apps/details?id=" + getPackageName());
                startActivity(Intent.createChooser(i, getResources().getString(R.string.app_name)));
            }
        });
        imgFeedback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.fromParts(
                        "mailto","jedyteam@gmail.com", null));
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, getResources().getString(R.string.app_name) + " - Your opinion");
                startActivity(Intent.createChooser(emailIntent, "Send feedback..."));
            }
        });
    }

    private void resetActivity(){
        gRunAgain.setVisibility(View.GONE);
        status = STATUS.NONE;
        txtThought.setText("");
        text.setText("");
        mSize = -1;
        headerTextIndex = -1;
        initMainStar();
        handler.post(new Runnable() {
            @Override
            public void run() {
                txtShowText.setText(R.string.first_header);
                showSlow(text, 3000);
                showSlow(button, 3000);
                showSlow(layoutMainStar, 3000);
                showSlow(txtThought, 3000);
                showSlow(txtShowText, 3000);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        if(!backgroundView.getIsAlive()) {
            backgroundView.updateView(true);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(isBoring && status == STATUS.RESUME){
            if(drawMainStarThread != null && drawMainStarThread.isAlive()){
                drawMainStarThread.interrupt();
                drawMainStarThread = null;
            }
            if(playMainHeader != null && playMainHeader.isAlive()){
                playMainHeader.interrupt();
            }
            drawMainStarThread = new DrawMainStarThread();
            playMainHeader = new PlayMainHeader();
            drawMainStarThread.start();
            playMainHeader.start();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        status = STATUS.STOP;
        backgroundView.updateView(false);
    }

    @Override
    protected void onDestroy() {
        sendBackgroundAction(ACTION.STOP);
        super.onDestroy();
    }

    private void setupUI(View view) {
        if (!(view instanceof EditText)) {
            view.setOnTouchListener(new View.OnTouchListener() {
                public boolean onTouch(View v, MotionEvent event) {
                    hideSoftKeyboard(MainActivity.this);
                    return false;
                }
            });
        }

        if (view instanceof ViewGroup) {
            for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                View innerView = ((ViewGroup) view).getChildAt(i);
                setupUI(innerView);
            }
        }
    }

    private static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager =
                (InputMethodManager) activity.getSystemService(
                        Activity.INPUT_METHOD_SERVICE);
        if(activity.getCurrentFocus() != null)
            inputMethodManager.hideSoftInputFromWindow(
                activity.getCurrentFocus().getWindowToken(), 0);
    }

    private void changeText(TextView view, String text) {
        hideSlow(view, 3000);
        view.setText(text);
        showSlow(view, 3000);
    }

    private void showSlow(final View view, int time) {
        view.setVisibility(View.VISIBLE);
        view.setAlpha(0.0f);
        view.animate()
                .alpha(1.0f)
                .setDuration(time)
                .setListener(null);
    }

    private void hideSlow(final View view, int time) {
        view.setAlpha(1.0f);
        view.animate()
                .alpha(0.0f)
                .setDuration(time)
                .setListener(new AnimatorListenerAdapter() {
                    @Override
                    public void onAnimationEnd(Animator animation) {
                        super.onAnimationEnd(animation);
                        view.setVisibility(View.GONE);
                    }
                });
    }

    private class DrawMainStarThread extends Thread {
        @Override
        public void run() {
            try {
                if(txtThought.getText().toString().trim().length() == 0)
                    return;
                if(status == STATUS.NONE) {
                    sleep(3000);
                }
                int size = mWidth / 4 + 2;
                if(status == STATUS.RESUME && mSize != -1){
                    size = mSize;
                }
                while (size >= 30) {
                    size -= 1;
                    if (size == 80) {
                        txtThought.post(new Runnable() {
                            @Override
                            public void run() {
                                txtThought.setVisibility(View.GONE);
                            }
                        });
                    }
                    if (size == 35) {
                        backgroundView.qe.offer(new Star(dx, dy, size/7, 7));
                        layoutMainStar.post(new Runnable() {
                            @Override
                            public void run() {
                                layoutMainStar.setVisibility(View.GONE);
                            }
                        });
                        break;
                    }
                    paramsMainStar.width = size * 2;
                    paramsMainStar.height = size * 2;
                    layoutMainStar.post(new Runnable() {
                        @Override
                        public void run() {
                            layoutMainStar.setLayoutParams(paramsMainStar);
                        }
                    });
                    mainStarView.drawMainStar(size);
                    sleep(57000 / (mWidth / 4));
                    if(status == STATUS.STOP){
                        mSize = size;
                        break;
                    }
                }
                if(size < 30){
                    isBoring = false;
                }
            } catch (InterruptedException e) {
            }

        }
    };


    private class PlayMainHeader extends Thread {
        @Override
        public void run() {
            try {
                if(txtThought.getText().toString().trim().length() == 0)
                    return;
                int i = 0;
                if(status == STATUS.RESUME && headerTextIndex != -1){
                    i = headerTextIndex;
                }
                for (; i < mainHeader.length; i++) {
                    if(i == mainHeader.length -1 ){
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if(gRunAgain.getVisibility() == View.GONE) {
                                    showSlow(gRunAgain, 1000);
                                    showSlow(gMore, 1000);
                                }

                            }
                        });
                    }
                    final String text = mainHeader[i];
                    sleep(1000);
                    txtShowText.post(new Runnable() {
                        @Override
                        public void run() {
                            changeText(txtShowText, text);
                        }
                    });
                    sleep(3000);
                    if(status == STATUS.STOP){
                        headerTextIndex = i;
                        break;
                    }
                }
                if(i >= mainHeader.length){
                    isBoring = false;
                }
            } catch (InterruptedException e) {
            }
        }
    };

    private void sendBackgroundAction(ACTION action){
        Intent intent = new Intent(action.getActionString());
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }
    private enum ACTION{
        START(Utils.START_MUSIC_ACTION),
        PAUSE(Utils.PAUSE_MUSIC_ACTION),
        STOP(Utils.STOP_MUSIC_ACTION);

        private String action_string;

        ACTION(String input){
            action_string = input;
        }
        public String getActionString(){
            return action_string;
        }

    }

    private enum STATUS{
        NONE,
        RESUME,
        STOP
    }
}
